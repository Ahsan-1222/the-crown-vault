export interface Product {
  id: string;
  name: string;
  price: string;
  description: string;
  category: 'jewellery' | 'bags' | 'perfumes';
  images: string[];
  details?: string[];
}

export const products: Product[] = [
  // Jewellery
  {
    id: 'jewel-001',
    name: 'Royal Diamond Necklace',
    price: '₹45,999',
    description: 'A stunning piece featuring ethically sourced diamonds set in 18K gold. This necklace embodies timeless elegance and sophistication.',
    category: 'jewellery',
    images: [
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&q=80',
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&q=80',
    ],
    details: ['18K Gold Setting', 'Ethically Sourced Diamonds', 'Certificate of Authenticity', 'Premium Gift Box']
  },
  {
    id: 'jewel-002',
    name: 'Pearl Drop Earrings',
    price: '₹12,499',
    description: 'Classic freshwater pearl earrings with a modern twist. Perfect for both casual and formal occasions.',
    category: 'jewellery',
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=800&q=80',
      'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=800&q=80',
    ],
    details: ['Freshwater Pearls', 'Sterling Silver Posts', 'Hypoallergenic', 'Elegant Packaging']
  },
  {
    id: 'jewel-003',
    name: 'Gold Chain Bracelet',
    price: '₹28,999',
    description: 'Delicate 22K gold chain bracelet with intricate craftsmanship. A must-have for every jewellery collection.',
    category: 'jewellery',
    images: [
      'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800&q=80',
      'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=800&q=80',
    ],
    details: ['22K Pure Gold', 'Handcrafted Design', 'Adjustable Length', 'Premium Finish']
  },
  {
    id: 'jewel-004',
    name: 'Ruby Statement Ring',
    price: '₹35,499',
    description: 'A bold ruby set in ornate gold, this statement ring commands attention and exudes royal charm.',
    category: 'jewellery',
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&q=80',
      'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=800&q=80',
    ],
    details: ['Natural Ruby', '18K Gold Band', 'Intricate Detailing', 'Ring Sizing Available']
  },

  // Bags
  {
    id: 'bag-001',
    name: 'Italian Leather Tote',
    price: '₹18,999',
    description: 'Handcrafted from premium Italian leather, this spacious tote combines functionality with unparalleled style.',
    category: 'bags',
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&q=80',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=800&q=80',
    ],
    details: ['100% Italian Leather', 'Cotton Lining', 'Interior Pockets', 'Dust Bag Included']
  },
  {
    id: 'bag-002',
    name: 'Evening Clutch',
    price: '₹8,499',
    description: 'Elegant clutch with subtle gold hardware, perfect for special evenings and formal events.',
    category: 'bags',
    images: [
      'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?w=800&q=80',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&q=80',
    ],
    details: ['Satin Finish', 'Magnetic Closure', 'Chain Strap Included', 'Gold Plated Hardware']
  },
  {
    id: 'bag-003',
    name: 'Crossbody Camera Bag',
    price: '₹14,999',
    description: 'Stylish camera bag silhouette in vegan leather. Features adjustable strap and multiple compartments.',
    category: 'bags',
    images: [
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&q=80',
      'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?w=800&q=80',
    ],
    details: ['Vegan Leather', 'Adjustable Strap', 'Multiple Pockets', 'Water Resistant']
  },
  {
    id: 'bag-004',
    name: 'Structured Satchel',
    price: '₹22,499',
    description: 'Professional yet chic structured satchel perfect for work or travel. Features laptop compartment.',
    category: 'bags',
    images: [
      'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800&q=80',
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&q=80',
    ],
    details: ['Premium PU Leather', 'Fits 15" Laptop', 'Organizer Interior', 'Detachable Shoulder Strap']
  },

  // Perfumes
  {
    id: 'perf-001',
    name: 'Royal Oud EDP',
    price: '₹4,999',
    description: 'An intoxicating blend of rare oud, amber, and sandalwood. A fragrance fit for royalty.',
    category: 'perfumes',
    images: [
      'https://images.unsplash.com/photo-1541643600914-78b084683601?w=800&q=80',
      'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=800&q=80',
    ],
    details: ['100ml Bottle', 'Long Lasting 8+ Hours', 'Unisex Fragrance', 'Gift Boxed']
  },
  {
    id: 'perf-002',
    name: 'Rose Essence Parfume',
    price: '₹3,299',
    description: 'Pure Bulgarian rose essence with hints of jasmine and musk. Romantic and feminine.',
    category: 'perfumes',
    images: [
      'https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=800&q=80',
      'https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?w=800&q=80',
    ],
    details: ['50ml Bottle', 'Natural Rose Extract', 'Floral Bouquet', 'Elegant Glass Bottle']
  },
  {
    id: 'perf-003',
    name: 'Midnight Musk',
    price: '₹2,799',
    description: 'Mysterious blend of white musk, vanilla, and amber. Perfect for evening wear.',
    category: 'perfumes',
    images: [
      'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=800&q=80',
      'https://images.unsplash.com/photo-1541643600914-78b084683601?w=800&q=80',
    ],
    details: ['75ml Bottle', 'Warm Musk Notes', 'Evening/Club Wear', 'Spray Atomizer']
  },
  {
    id: 'perf-004',
    name: 'Citrus Breeze EDT',
    price: '₹2,499',
    description: 'Fresh and invigorating blend of bergamot, lemon, and green tea. Ideal for daily use.',
    category: 'perfumes',
    images: [
      'https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?w=800&q=80',
      'https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=800&q=80',
    ],
    details: ['100ml Bottle', 'Citrus Fresh', 'Day Wear', 'Travel Size Available']
  }
];

export const getProductsByCategory = (category: string) => {
  return products.filter(p => p.category === category);
};

export const getProductById = (id: string) => {
  return products.find(p => p.id === id);
};
