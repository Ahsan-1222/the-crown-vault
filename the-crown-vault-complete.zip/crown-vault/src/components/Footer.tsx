import { Mail, Phone, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const whatsappNumber = '91XXXXXXXXXX';
  const email = 'contact@thecrownvault.com';

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              The Crown Vault
            </h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Your destination for luxury jewellery, designer bags, and premium perfumes. 
              Elevate your style with our curated collection.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-sm hover:text-gold transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/category/jewellery" className="text-sm hover:text-gold transition-colors">
                  Jewellery
                </Link>
              </li>
              <li>
                <Link to="/category/bags" className="text-sm hover:text-gold transition-colors">
                  Bags
                </Link>
              </li>
              <li>
                <Link to="/category/perfumes" className="text-sm hover:text-gold transition-colors">
                  Perfumes
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-sm hover:text-gold transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Get in Touch</h4>
            <div className="space-y-3">
              <a
                href={`https://wa.me/${whatsappNumber}?text=Hi, I'm interested in your products`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm hover:text-gold transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp Us
              </a>
              <a
                href={`mailto:${email}`}
                className="flex items-center gap-2 text-sm hover:text-gold transition-colors"
              >
                <Mail className="w-4 h-4" />
                {email}
              </a>
              <a
                href={`tel:+${whatsappNumber}`}
                className="flex items-center gap-2 text-sm hover:text-gold transition-colors"
              >
                <Phone className="w-4 h-4" />
                +{whatsappNumber}
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-gray-800 text-center">
          <p className="text-xs text-gray-500">
            © {currentYear} The Crown Vault. All rights reserved. Crafted with elegance.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
