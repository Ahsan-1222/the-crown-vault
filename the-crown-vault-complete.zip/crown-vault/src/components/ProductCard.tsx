import { Link } from 'react-router-dom';
import { Eye, ShoppingCart } from 'lucide-react';
import type { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  return (
    <div className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://via.placeholder.com/400x400?text=Image';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Category Badge */}
        <span className="absolute top-3 left-3 bg-cream/90 backdrop-blur-sm text-gold-dark text-xs font-medium px-3 py-1 rounded-full uppercase tracking-wide">
          {product.category}
        </span>
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-gold transition-colors duration-200 line-clamp-1" style={{ fontFamily: 'Playfair Display, serif' }}>
          {product.name}
        </h3>
        <p className="text-gold font-bold text-xl mb-4">
          {product.price}
        </p>
        
        {/* Actions */}
        <div className="flex gap-2">
          <Link
            to={`/product/${product.id}`}
            className="flex-1 flex items-center justify-center gap-2 bg-gray-100 hover:bg-gold hover:text-white text-gray-700 font-medium py-2.5 px-4 rounded-xl transition-all duration-200 text-sm"
          >
            <Eye className="w-4 h-4" />
            View
          </Link>
          <Link
            to={`/product/${product.id}`}
            className="flex-1 flex items-center justify-center gap-2 bg-gold hover:bg-gold-dark text-white font-medium py-2.5 px-4 rounded-xl transition-all duration-200 text-sm"
          >
            <ShoppingCart className="w-4 h-4" />
            Buy Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
