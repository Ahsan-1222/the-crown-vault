import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// Replace these values with your actual Firebase config
const firebaseConfig = {
  apiKey: "REPLACE_WITH_YOUR_API_KEY",
  authDomain: "REPLACE_WITH_YOUR_AUTH_DOMAIN",
  projectId: "REPLACE_WITH_YOUR_PROJECT_ID",
  storageBucket: "REPLACE_WITH_YOUR_STORAGE_BUCKET",
  messagingSenderId: "REPLACE_WITH_YOUR_MESSAGING_SENDER_ID",
  appId: "REPLACE_WITH_YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

// Function to log orders to Firestore
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export interface OrderData {
  productName: string;
  productPrice: string;
  productId?: string;
  category?: string;
  timestamp: any;
}

export const logOrder = async (orderData: Omit<OrderData, 'timestamp'>) => {
  try {
    const docRef = await addDoc(collection(db, 'orders'), {
      ...orderData,
      timestamp: serverTimestamp()
    });
    console.log('Order logged with ID:', docRef.id);
    return docRef.id;
  } catch (error) {
    console.error('Error logging order:', error);
    throw error;
  }
};
