import { useParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { getProductsByCategory } from '../data/products';
import { Gem, Handbag, Flame } from 'lucide-react';

const CategoryPage = () => {
  const { category } = useParams<{ category: string }>();

  const products = category ? getProductsByCategory(category) : [];

  const categoryInfo = {
    jewellery: {
      title: 'Jewellery Collection',
      description: 'Discover our exquisite range of handcrafted jewellery pieces. From timeless classics to contemporary designs.',
      icon: Gem,
      image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1200&q=80',
    },
    bags: {
      title: 'Bags Collection',
      description: 'Explore our designer bags collection. From elegant totes to chic clutches, find your perfect companion.',
      icon: Handbag,
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=1200&q=80',
    },
    perfumes: {
      title: 'Perfumes Collection',
      description: 'Immerse yourself in our signature fragrances. Each scent is crafted to leave a lasting impression.',
      icon: Flame,
      image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=1200&q=80',
    },
  };

  const info = categoryInfo[category as keyof typeof categoryInfo];
  const Icon = info?.icon || Gem;

  if (!info) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Category not found</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Banner */}
      <section className="relative h-[40vh] min-h-[300px] overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${info.image})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
        </div>
        
        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 bg-gold/20 backdrop-blur-sm text-gold-light px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Icon className="w-4 h-4" />
              {category?.charAt(0).toUpperCase() + category?.slice(1)}
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              {info.title}
            </h1>
            <p className="text-gray-200 text-lg">
              {info.description}
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 bg-cream">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <p className="text-gray-600">
              <span className="font-semibold text-gray-900">{products.length}</span> products found
            </p>
          </div>

          {products.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <Icon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No products available</h3>
              <p className="text-gray-600">Check back soon for new arrivals!</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default CategoryPage;
