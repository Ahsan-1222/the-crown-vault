import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, ShoppingCart, Check, Copy, CheckCheck } from 'lucide-react';
import { getProductById } from '../data/products';
import { logOrder } from '../firebase';

const ProductDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const product = id ? getProductById(id) : undefined;
  const [selectedImage, setSelectedImage] = useState(0);
  const [isOrdering, setIsOrdering] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderError, setOrderError] = useState<string | null>(null);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Product not found</h1>
          <Link to="/" className="text-gold hover:text-gold-dark">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  const handleBuyNow = async () => {
    setIsOrdering(true);
    setOrderError(null);

    try {
      // Log order to Firestore
      await logOrder({
        productName: product.name,
        productPrice: product.price,
        productId: product.id,
        category: product.category,
      });

      // Open pre-filled Google Form
      const formUrl = `https://docs.google.com/forms/d/e/REPLACE_WITH_MY_FORM_ID/viewform?usp=pp_url&entry.1111=${encodeURIComponent(product.name)}&entry.2222=${encodeURIComponent(product.price)}`;
      window.open(formUrl, '_blank');

      setOrderSuccess(true);
      setTimeout(() => setOrderSuccess(false), 3000);
    } catch (error) {
      console.error('Error:', error);
      setOrderError('Failed to process order. Please try again.');
    } finally {
      setIsOrdering(false);
    }
  };

  const nextImage = () => {
    setSelectedImage((prev) => (prev + 1) % product.images.length);
  };

  const prevImage = () => {
    setSelectedImage((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  return (
    <div className="min-h-screen pt-20 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <ol className="flex items-center gap-2 text-sm">
            <li>
              <Link to="/" className="text-gray-500 hover:text-gold transition-colors">
                Home
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li>
              <Link 
                to={`/category/${product.category}`} 
                className="text-gray-500 hover:text-gold transition-colors capitalize"
              >
                {product.category}
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li className="text-gray-900 font-medium">{product.name}</li>
          </ol>
        </nav>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="relative aspect-square bg-white rounded-2xl overflow-hidden shadow-lg">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://via.placeholder.com/800x800?text=Image';
                }}
              />
              
              {product.images.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
                    aria-label="Previous image"
                  >
                    <ChevronLeft className="w-5 h-5 text-gray-700" />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
                    aria-label="Next image"
                  >
                    <ChevronRight className="w-5 h-5 text-gray-700" />
                  </button>
                </>
              )}

              <span className="absolute top-4 left-4 bg-gold text-white text-xs font-medium px-3 py-1.5 rounded-full uppercase tracking-wide">
                {product.category}
              </span>
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                      selectedImage === index 
                        ? 'border-gold shadow-md' 
                        : 'border-transparent hover:border-gold/50'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/100x100?text=Thumb';
                      }}
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                {product.name}
              </h1>
              <div className="flex items-center gap-4">
                <span className="text-4xl font-bold text-gold">
                  {product.price}
                </span>
              </div>
            </div>

            <div className="border-t border-b border-gray-200 py-6">
              <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wide mb-3">
                Description
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {product.description}
              </p>
            </div>

            {product.details && product.details.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wide mb-3">
                  Features
                </h3>
                <ul className="space-y-2">
                  {product.details.map((detail, index) => (
                    <li key={index} className="flex items-center gap-3 text-gray-600">
                      <Check className="w-4 h-4 text-gold flex-shrink-0" />
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Order Status */}
            {orderError && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">
                {orderError}
              </div>
            )}

            {/* Buy Button */}
            <button
              onClick={handleBuyNow}
              disabled={isOrdering}
              className={`w-full flex items-center justify-center gap-3 py-4 px-8 rounded-xl font-semibold text-lg transition-all duration-300 ${
                isOrdering
                  ? 'bg-gray-400 cursor-not-allowed'
                  : orderSuccess
                  ? 'bg-green-500 hover:bg-green-600'
                  : 'bg-gold hover:bg-gold-dark transform hover:scale-[1.02] shadow-lg hover:shadow-xl'
              } text-white`}
            >
              {isOrdering ? (
                <>
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </>
              ) : orderSuccess ? (
                <>
                  <CheckCheck className="w-5 h-5" />
                  Order Logged! Opening Form...
                </>
              ) : (
                <>
                  <ShoppingCart className="w-5 h-5" />
                  Buy Now
                </>
              )}
            </button>

            <p className="text-xs text-gray-500 text-center">
              You'll be redirected to complete your order. Your selection will be pre-filled.
            </p>

            {/* WhatsApp CTA */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <p className="text-sm text-gray-600 mb-3">
                Have questions? Chat with us directly on WhatsApp!
              </p>
              <a
                href={`https://wa.me/91XXXXXXXXXX?text=Hi, I'm interested in ${encodeURIComponent(product.name)} (${product.price})`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium"
              >
                <Copy className="w-4 h-4" />
                Chat on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
